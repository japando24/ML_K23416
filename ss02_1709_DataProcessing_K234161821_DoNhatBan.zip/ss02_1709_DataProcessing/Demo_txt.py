import pandas as pd
df = pd.read_csv("../datasets/SalesTransactions/SalesTransactions.txt",
                 sep='\t')
print(df)
#Trỏ path cần đồng cấp
#../../datasets/